# Privacy

- No content capture. Only counts and window exe/title. Option to remove titles if needed.
- Input metrics paused for excluded apps; time-in-app still tracked.
- All data stored locally in data/.
- Gemini calls send only summaries (no raw keystrokes). Stress sends compact multi-day features.
- Optional: redact titles, add idle detection, retention.
