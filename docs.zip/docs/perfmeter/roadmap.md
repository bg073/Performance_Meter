# Roadmap

- Idle detection and focus time.
- Title privacy toggle.
- Log retention (30/60 days).
- Live periodic Gemini scoring.
- Export daily HTML/PDF reports.
- Multi-platform (macOS/Linux) abstraction.
