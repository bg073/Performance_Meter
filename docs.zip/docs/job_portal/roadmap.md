# Roadmap

- Add login/auth for admin.
- OCR for scanned PDFs.
- Skill extraction and normalization.
- Candidate deduplication and notes.
- Export shortlist to CSV.
- More sophisticated Gemini filter prompts per role.
