# Privacy

- Resumes stored locally; parsed text stored in SQLite.
- Gemini-assisted filter uses compact corpus statistics only—no full resumes sent.
- Admin-only endpoints; do not expose publicly.
- Consider adding password protection if needed.
