# Wireframes

## Admin
```
+--------------------------------------------------+
| Job Portal (Admin)       [+ New Job]             |
+--------------------------------------------------+
| Jobs Table                                          
|  ID | Title | Created | Actions [View]             
+--------------------------------------------------+
```

## Job Page
```
<- Back  | Title
[Public apply link]
[Applications Card: View candidates]
[Questions Card: list]
```

## Apply
```
<- Back
Name | Email
Upload Resume
Answers (per question)
[Submit]
```

## Candidates
```
<- Back
[Filters Form]
[Propose Filters] [Suggest with Gemini]
[Candidates Table]
```
