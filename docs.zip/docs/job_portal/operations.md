# Operations

## Run
- .\.venv\Scripts\python .\run_job_portal.py
- Open http://127.0.0.1:8770/

## Troubleshooting
- Syntax errors: ensure no stray JS in Python modules.
- Upload issues: check data/job_portal/uploads writable.
- PDF parsing: scanned PDFs may produce poor text (OCR not included).
